﻿namespace DagreSharp.GraphLibrary
{
	// Implementation notes:
	//
	//  * Node id query functions should return string ids for the nodes
	//  * Edge id query functions should return an "edgeObj", edge object, that is
	//    composed of enough information to uniquely identify an edge: {v, w, name}.
	//  * Internally we use an "edgeId", a stringified form of the edgeObj, to
	//    reference edges. This is because we need a performant way to look these
	//    edges up and, object properties, which have string keys, are the closest
	//    we're going to get to a performant hashtable in JavaScript.
	public class Graph
	{
		private const string DEFAULT_EDGE_NAME = "\x00";
		private const string GRAPH_NODE = "\x00";
		private const string EDGE_KEY_DELIM = "\x01";

		// Defaults to be set when creating a new node
		private Func<string, string>? _defaultNodeLabelFn = null;

		// Defaults to be set when creating a new edge
		Func<string, string, string, string>? _defaultEdgeLabelFn = null;

		// v -> label
		private readonly Dictionary<string, object> _nodes = [];

		// v -> edgeObj
		private readonly Dictionary<string, Dictionary<string, Edge>> _in = [];

		// u -> v -> Number
		private readonly Dictionary<string, List<string>> _preds = [];

		// v -> edgeObj
		private readonly Dictionary<string, Dictionary<string, Edge>> _out = [];

		// v -> w -> Number
		private readonly Dictionary<string, List<string>> _sucs = [];

		// e -> edgeObj
		private readonly Dictionary<string, Edge> _edgeObjs = [];

		/* Number of nodes in the graph. Should only be changed by the implementation. */
		int _nodeCount = 0;

		/* Number of edges in the graph. Should only be changed by the implementation. */
		int _edgeCount = 0;

		private readonly Dictionary<string, string> _parent = [];

		private readonly Dictionary<string, HashSet<string>> _children = [];

		public bool IsDirected { get; }
		public bool IsMultigraph { get; }
		public bool IsCompound { get; }
		public GraphLabel Label { get; set; }

		public Graph(bool isDirected = true, bool isMultigraph = false, bool isCompound = false)
		{
			IsDirected = isDirected;
			IsMultigraph = isMultigraph;
			IsCompound = isCompound;
			Label = new GraphLabel();

			if (IsCompound)
			{
				_children.Add(GRAPH_NODE, []);
			}
		}

		/* === Graph functions ========= */

		///**
		// * Sets the label of the graph.
		// */
		//public Graph setGraph(GraphLabel label)
		//{
		//	this._label = label;
		//	return this;
		//}

		///**
		// * Gets the graph label.
		// */
		//public GraphLabel getGraph()
		//{
		//	return this._label;
		//}


		//			/* === Node functions ========== */

		/**
		 * Sets the default node label. If newDefault is a function, it will be
		 * invoked ach time when setting a label for a node. Otherwise, this label
		 * will be assigned as default label in case if no label was specified while
		 * setting a node.
		 * Complexity: O(1).
		 */
		public Graph setDefaultNodeLabel(Func<string, string> newDefault)
		{
			this._defaultNodeLabelFn = newDefault;
			return this;
		}

		/**
		 * Gets the number of nodes in the graph.
		 * Complexity: O(1).
		 */
		public int nodeCount()
		{
			return this._nodeCount;
		}

		/**
		 * Gets all nodes of the graph. Note, the in case of compound graph subnodes are
		 * not included in list.
		 * Complexity: O(1).
		 */
		public ICollection<string> nodes()
		{
			return [.. _nodes.Keys];
		}

		/**
		 * Gets list of nodes without in-edges.
		 * Complexity: O(|V|).
		 */
		public ICollection<string> sources()
		{
			return [.. this.nodes().Where(v => _in[v].Count == 0)];
		}

		/**
		 * Gets list of nodes without out-edges.
		 * Complexity: O(|V|).
		 */
		public ICollection<string> sinks()
		{
			return [.. this.nodes().Where(v => _out[v].Count == 0)];
		}

		/**
		 * Invokes setNode method for each node in names list.
		 * Complexity: O(|names|).
		 */
		public Graph setNodes(IEnumerable<string> vs, object? value = null)
		{
			foreach (var v in vs)
			{
				setNode(v, value);
			}

			return this;
		}

		/**
		 * Creates or updates the value for the node v in the graph. If label is supplied
		 * it is set as the value for the node. If label is not supplied and the node was
		 * created by this call then the default node label will be assigned.
		 * Complexity: O(1).
		 */
		public Graph setNode(string v, object? value = null)
		{
			if (_nodes.ContainsKey(v))
			{
				if (value != null)
				{
					this._nodes[v] = value;
				}
				return this;
			}

			this._nodes[v] = value != null ? value : this._defaultNodeLabelFn(v);
			if (IsCompound)
			{
				this._parent[v] = GRAPH_NODE;
				this._children[v] = [];
				//this._children[GRAPH_NODE][v] = true;
			}
			this._in[v] = [];
			this._preds[v] = [];
			this._out[v] = [];
			this._sucs[v] = [];
			++this._nodeCount;
			return this;
		}

		/**
		 * Gets the label of node with specified name.
		 * Complexity: O(|V|).
		 */
		public object node(string v)
		{
			return this._nodes[v];
		}

		/**
		 * Detects whether graph has a node with specified name or not.
		 */
		public bool hasNode(string v)
		{
			return _nodes.ContainsKey(v);
		}

		/**
		 * Remove the node with the name from the graph or do nothing if the node is not in
		 * the graph. If the node was removed this function also removes any incident
		 * edges.
		 * Complexity: O(1).
		 */
		public Graph removeNode(string v)
		{
			if (_nodes.ContainsKey(v))
			{
				Func<string, Graph> removeEdge = e => this.removeEdge(_edgeObjs[e]);
				_nodes.Remove(v);

				if (IsCompound)
				{
					_removeFromParentsChildList(v);
					foreach (var child in children(v))
					{
						setParent(child);
					}
					_children.Remove(v);
				}

				foreach (var item in _in[v].Keys)
				{
					removeEdge(item);
				}

				_in.Remove(v);
				_preds.Remove(v);

				foreach (var item in _out[v].Keys)
				{
					removeEdge(item);
				}
				_out.Remove(v);
				_sucs.Remove(v);
				--this._nodeCount;
			}
			return this;
		}

		/**
		 * Sets node p as a parent for node v if it is defined, or removes the
		 * parent for v if p is undefined. Method throws an exception in case of
		 * invoking it in context of noncompound graph.
		 * Average-case complexity: O(1).
		 */
		public Graph setParent(string v, string? parent = null)
		{
			if (!IsCompound)
			{
				throw new InvalidOperationException("Cannot set parent in a non-compound graph");
			}

			if (parent == null)
			{
				parent = GRAPH_NODE;
			}
			else
			{
				for (var ancestor = parent; !string.IsNullOrEmpty(ancestor) /*ancestor != undefined*/; ancestor = this.parent(ancestor))
				{
					if (ancestor == v)
					{
						throw new InvalidOperationException("Setting " + parent + " as parent of " + v + " would create a cycle");
					}
				}

				this.setNode(parent);
			}

			this.setNode(v);
			this._removeFromParentsChildList(v);
			this._parent[v] = parent;
			//this._children[parent][v] = true;
			return this;
		}

		private void _removeFromParentsChildList(string v)
		{
			_parent.Remove(v);
			//delete this._children[this._parent[v]][v];
		}

		/**
		 * Gets parent node for node v.
		 * Complexity: O(1).
		 */
		public string parent(string v)
		{
			if (IsCompound)
			{
				var parent = _parent[v];
				if (parent != GRAPH_NODE)
				{
					return parent;
				}
			}

			return null;
		}

		/**
		 * Gets list of direct children of node v.
		 * Complexity: O(1).
		 */
		public ICollection<string> children(string v = GRAPH_NODE)
		{
			if (IsCompound)
			{
				return _children[v];
			}
			else if (v == GRAPH_NODE)
			{
				return nodes();
			}

			return [];
		}

		/**
		 * Return all nodes that are predecessors of the specified node or undefined if node v is not in
		 * the graph. Behavior is undefined for undirected graphs - use neighbors instead.
		 * Complexity: O(|V|).
		 */
		public ICollection<string> predecessors(string v)
		{
			return _preds.ContainsKey(v) ? this._preds[v] : [];
		}

		/**
		 * Return all nodes that are successors of the specified node or undefined if node v is not in
		 * the graph. Behavior is undefined for undirected graphs - use neighbors instead.
		 * Complexity: O(|V|).
		 */
		public ICollection<string> successors(string v)
		{
			return _sucs.ContainsKey(v) ? this._sucs[v] : [];
		}

		/**
		 * Return all nodes that are predecessors or successors of the specified node or undefined if
		 * node v is not in the graph.
		 * Complexity: O(|V|).
		 */
		public ICollection<string> neighbors(string v)
		{
			var preds = this.predecessors(v);
			var sucs = this.successors(v);

			return [.. preds.Union(sucs)];
		}

		public bool isLeaf(string v)
		{
			var neighbors = IsMultigraph ? this.successors(v) : this.neighbors(v);
			return neighbors.Count == 0;
		}

		/**
		 * Creates new graph with nodes filtered via filter. Edges incident to rejected node
		 * are also removed. In case of compound graph, if parent is rejected by filter,
		 * than all its children are rejected too.
		 * Average-case complexity: O(|E|+|V|).
		 */
		public Graph filterNodes(Func<string, bool> filter)
		{
			var copy = new Graph(IsDirected, IsMultigraph, IsCompound);
			copy.Label = Label;

			foreach (var v in _nodes.Keys)
			{
				if (filter(v))
				{
					copy.setNode(v);
				}
			}

			foreach (var e in _edgeObjs.Values)
			{
				if (copy.hasNode(e.v) && copy.hasNode(e.w))
				{
					copy.setEdge(e);
				}
			}

			foreach (var e in _edgeObjs.Values)
			{
				if (copy.hasNode(e.v) && copy.hasNode(e.w))
				{
					copy.setEdge(e);
				}
			}

			var parents = new Dictionary<string, string>();
			string findParent(string v)
			{
				var parent = this.parent(v);
				if (string.IsNullOrEmpty(parent) || copy.hasNode(parent))
				{
					parents[v] = parent;
					return parent;
				}
				else if (parents.ContainsKey(parent))
				{
					return parents[parent];
				}
				else
				{
					return findParent(parent);
				}
			}

			if (IsCompound)
			{
				foreach (var v in copy.nodes())
				{
					copy.setParent(v, findParent(v));
				}
			}

			return copy;
		}

		//			/* === Edge functions ========== */

		/**
		 * Sets the default edge label or factory function. This label will be
		 * assigned as default label in case if no label was specified while setting
		 * an edge or this function will be invoked each time when setting an edge
		 * with no label specified and returned value * will be used as a label for edge.
		 * Complexity: O(1).
		 */
		public Graph setDefaultEdgeLabel(Func<string, string, string, string> newDefault)
		{
			this._defaultEdgeLabelFn = newDefault;
			return this;
		}

		/**
		 * Gets the number of edges in the graph.
		 * Complexity: O(1).
		 */
		public int edgeCount()
		{
			return _edgeCount;
		}

		/**
		 * Gets edges of the graph. In case of compound graph subgraphs are not considered.
		 * Complexity: O(|E|).
		 */
		public ICollection<Edge> edges()
		{
			return _edgeObjs.Values;
		}

		/**
		 * Establish an edges path over the nodes in nodes list. If some edge is already
		 * exists, it will update its label, otherwise it will create an edge between pair
		 * of nodes with label provided or default label if no label provided.
		 * Complexity: O(|nodes|).
		 */
		public Graph setPath(IEnumerable<string> vs)
		{
			string w = string.Empty;
			foreach (var v in vs)
			{
				if (!string.IsNullOrEmpty(w))
				{
					setEdge(v, w);
				}
				w = v;
			}

			return this;
		}

		/**
		 * Creates or updates the label for the edge (v, w) with the optionally supplied
		 * name. If label is supplied it is set as the value for the edge. If label is not
		 * supplied and the edge was created by this call then the default edge label will
		 * be assigned. The name parameter is only useful with multigraphs.
		 */
		public Graph setEdge(Edge edge)
		{
			var v = edge.v;
			var w = edge.w;
			var name = edge.name;

			var e = edgeArgsToId(v, w, name);

			if (!string.IsNullOrEmpty(name) && !IsMultigraph)
			{
				throw new InvalidOperationException("Cannot set a named edge when isMultigraph = false");
			}

			// It didn't exist, so we need to create it.
			// First ensure the nodes exist.
			this.setNode(v);
			this.setNode(w);

			var edgeObj = edgeArgsToObj(v, w, name);
			edgeObj.EdgeLabelFunc = _defaultEdgeLabelFn;
			// Ensure we add undirected edges in a consistent way.
			v = edgeObj.v;
			w = edgeObj.w;

			this._edgeObjs[e] = edgeObj;
			this._in[w][e] = edgeObj;
			this._out[v][e] = edgeObj;
			this._edgeCount++;
			return this;
		}

		public Graph setEdge(string v, string w, string? name = null)
		{
			var edgeObj = edgeArgsToObj(v, w, name);
			return setEdge(edgeObj);
		}

		/**
		 * Gets the label for the specified edge.
		 * Complexity: O(1).
		 */
		public Edge edge(string v, string w, string? name = null)
		{
			var e = edgeArgsToId(v, w, name);
			return _edgeObjs[e];
		}

		public Edge edge(Edge edge)
		{
			var e = edgeObjToId(edge);
			return _edgeObjs[e];
		}

		/**
		 * Gets the label for the specified edge and converts it to an object.
		 * Complexity: O(1)
		 */
		public Edge edgeAsObj(string v, string w, string? name = null)
		{
			return this.edge(v, w, name);
		}

		/**
		 * Detects whether the graph contains specified edge or not. No subgraphs are considered.
		 * Complexity: O(1).
		 */
		public bool hasEdge(string v, string w, string? name = null)
		{
			var e = edgeArgsToId(v, w, name);
			return _edgeObjs.ContainsKey(e);
		}

		public bool hasEdge(Edge edge)
		{
			var e = edgeObjToId(edge);
			return _edgeObjs.ContainsKey(e);
		}

		/**
		 * Removes the specified edge from the graph. No subgraphs are considered.
		 * Complexity: O(1).
		 */
		public Graph removeEdge(string v, string w, string? name = null)
		{
			var e = edgeArgsToId(v, w, name);
			return doRemoveEdge(v, w, e);
		}

		public Graph removeEdge(Edge edge)
		{
			var e = edgeObjToId(edge);
			return doRemoveEdge(edge.v, edge.w, e);
		}

		private Graph doRemoveEdge(string v, string w, string e)
		{
			var edge = this._edgeObjs[e];
			if (edge != null)
			{
				v = edge.v;
				w = edge.w;
				_edgeObjs.Remove(e);
				_in[w].Remove(e);
				_out[v].Remove(e);
				this._edgeCount--;
			}
			return this;
		}

		/**
		 * Return all edges that point to the node v. Optionally filters those edges down to just those
		 * coming from node u. Behavior is undefined for undirected graphs - use nodeEdges instead.
		 * Complexity: O(|E|).
		 */
		public ICollection<Edge> inEdges(string v, string u)
		{
			var edges = new List<Edge>();

			if (_in.TryGetValue(v, out Dictionary<string, Edge>? value))
			{
				edges.AddRange(value.Values);
				if (u != null)
				{
					edges = [.. edges.Where(e => e.v == u)];
				}
			}

			return edges;
		}

		/**
		 * Return all edges that are pointed at by node v. Optionally filters those edges down to just
		 * those point to w. Behavior is undefined for undirected graphs - use nodeEdges instead.
		 * Complexity: O(|E|).
		 */
		public ICollection<Edge> outEdges(string v, string w)
		{
			var edges = new List<Edge>();

			if (_out.TryGetValue(v, out Dictionary<string, Edge>? value))
			{
				edges.AddRange(value.Values);
				if (w != null)
				{
					edges = [.. edges.Where(e => e.v == w)];
				}
			}

			return edges;
		}

		/**
		 * Returns all edges to or from node v regardless of direction. Optionally filters those edges
		 * down to just those between nodes v and w regardless of direction.
		 * Complexity: O(|E|).
		 */
		public ICollection<Edge> nodeEdges(string v, string w)
		{
			var edges = this.inEdges(v, w).ToList();
			edges.AddRange(outEdges(v, w));

			return edges;
		}

		private string edgeArgsToId(string v, string w, string? name = null)
		{
			if (!IsDirected && string.Compare(v, w, StringComparison.OrdinalIgnoreCase) > 0)
			{
				(w, v) = (v, w);
			}

			return v + EDGE_KEY_DELIM + w + EDGE_KEY_DELIM + (name == null ? DEFAULT_EDGE_NAME : name);
		}

		private Edge edgeArgsToObj(string v, string w, string? name = null)
		{
			if (!IsDirected && string.Compare(v, w, StringComparison.OrdinalIgnoreCase) > 0)
			{
				(w, v) = (v, w);
			}

			var edgeObj = new Edge { v = v, w = w };
			edgeObj.name = name;

			return edgeObj;
		}

		private string edgeObjToId(Edge edge)
		{
			return edgeArgsToId(edge.v, edge.w, edge.name);
		}
	}
}