﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DagreSharp.GraphLibrary
{
	public class Edge
	{
		public string v { get; set; }

		public string w { get; set; }

		public string? name { get; set; }

		public Func<string, string, string, string> EdgeLabelFunc { get; set; }
	}
}
