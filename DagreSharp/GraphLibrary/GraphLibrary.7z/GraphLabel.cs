﻿namespace DagreSharp.GraphLibrary
{
	public class GraphLabel
	{
		public RankDirection RankDirection { get; set; }

		public int MarginX { get; set; }

		public int MarginY { get; set; }

		public int NodeSeparation { get; set; } = 50;

		public int EdgeSeparation { get; set; } = 20;

		public int RankSeparation { get; set; } = 50;
	}
}
