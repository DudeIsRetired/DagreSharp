﻿namespace DagreSharp.GraphLibrary
{
	public enum RankDirection
	{
		None = 0,
		TopBottom,
		BottomTop,
		LeftRight,
		RightLeft
	}
}
